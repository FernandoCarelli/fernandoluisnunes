<html lang="pt-br"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>XasTree Investimentos</title>

    <!-- Principal CSS do Bootstrap -->
    <link href="../bootstrap-4.5.2-dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Estilos customizados para esse template -->
    <link href="dashboard.css" rel="stylesheet">
  <style type="text/css">/* Chart.js */
@-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style></head>

  <body>
    
  

  
    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="../Funcionario/cadastroFuncionario.php">
                  
                  Funcionarios <span class="sr-only">(atual)</span>
                </a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link active" href="../corretor/CadastroCorretor.php">
                  
                  Corretor <span class="sr-only">(atual)</span>
                </a>
              </li>

              <li class="nav-item">
                <a class="nav-link active" href="../investimento/investimento.php">
                  
                  Investimento <span class="sr-only">(atual)</span>
                </a>
              </li>





            </ul>
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4"><div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;"><div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div></div><div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:200%;height:200%;left:0; top:0"></div></div></div>
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Investimentos</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
              
            </div>
          </div>
          <img src="grafico.jpeg" align="left" vspace="50px" hspace="200px">
          <canvas class="my-4 w-100 chartjs-render-monitor" id="myChart" width="547" height="230" style="display: block; width: 547px; height: 230px;"></canvas>

        
          
    

    
  

</body></html>