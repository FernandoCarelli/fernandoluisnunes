<!-- Principal CSS do Bootstrap -->
<link href="../bootstrap-4.5.2-dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Estilos customizados para esse template -->
<link href="dashboard.css" rel="stylesheet">
<style type="text/css">/* Chart.js */
@-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style></head>


<div style="margin-top: 30px;" class="container">
        <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">

            <h3>Dados Funcionario nº<?php echo $registo["IDFuncionario"]; ?></h3><br>
            <p>Nome <input type="text" name="Nome" size="50" value="<?php echo $registo["Nome"]; ?>"></p>
            <p>Username<input type="text" name="username" size="47" value="<?php echo $registo["username"]; ?>"></p>
            <p>Password<input type="text" name="password" size="47" value="<?php echo $registo["password"]; ?>"></p>
            <p>Morada<input type="text" name="morada" size="49" value="<?php echo $registo["morada"]; ?>"></p>
            <p>Contacto <input type="text" name="contacto" size="47" maxlength="9" value="<?php echo $registo["contacto"]; ?>"></p><br>
            <p><input type="submit" value="Alterar" name="alterar"><input type="reset" value="Repor" name="B2"></p>
        </form>
</div>