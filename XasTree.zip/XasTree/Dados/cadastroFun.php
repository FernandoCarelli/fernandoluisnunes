<?php

class Funcionario{
private $idFuncionario, $emailFuncionario, $first_nameFuncionario, $last_nameFuncionario, $avatarFuncionario;

public function setidFuncionario($idFuncionario){
 $this->idFuncionario = $idFuncionario;
}
public function setfirst_nameFuncionario($first_nameFuncionario){
 $this->first_nameFuncionario = $first_nameFuncionario;
}
public function setlast_nameFuncionario($last_nameFuncionario){
 $this->last_nameFuncionario = $last_nameFuncionario;
}
public function setavatarFuncionario($avatarFuncionario){
 $this->avatarFuncionario = $avatarFuncionario;
}


public function getidFuncionario(){
 return $this->idFuncionario;
}
public function getfirst_nameFuncionario(){
 return $this->first_nameFuncionario;
}
public function getlast_nameFuncionario(){
 return $this->last_nameFuncionario;
}
public function getavatarFuncionario(){
 return $this->avatarFuncionario;
}



public function cadastrar($idFuncionario, $first_NameFuncionario, $last_nameFuncionario,
$avatarFuncionario){

 $this->setidFuncionario($idFuncionario);
 $this->setfirst_nameFuncionario($first_nameFuncionario);
 $this->setlast_nameFuncionario($last_nameFuncionario);
 $this->setavatarFuncionario($avatarFuncionario);
 



$sql = "insert into cadastroFun
 (idFuncionario, first_nameFuncionario, last_nameFuncionario, avatarFuncionario)
  values
 (
'{$this->getidFuncionario()}',
'{$this->getfirst_nameFuncionario()}',
'{$this->getlast_nameFuncionario()}',
'{$this->getavatarFuncionario()}',
 )";

 include '../conexcao/conexao.php';
 $inserir = $conectar-> query($sql);

$registroAfetados = $conectar->affected_rows;
if ($registroAfetados == 1){
 return 1;
}else{
 return 0;
 }

}
}
?>
 
