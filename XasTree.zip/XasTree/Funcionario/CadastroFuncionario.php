<!-- Principal CSS do Bootstrap -->
<link href="../bootstrap-4.5.2-dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Estilos customizados para esse template -->
<link href="dashboard.css" rel="stylesheet">
<style type="text/css">/* Chart.js */
@-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style></head>


<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Cadastro de Funcionarios</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
              
            </div>
          </div>

          <!--<canvas class="my-4 w-100 chartjs-render-monitor" id="myChart" width="547" height="230" style="display: block; width: 547px; height: 230px;"></canvas>-->




<div style="margin-top: 30px;" class="container">

 <Form action="../dados/cadastroFun.php" method="post">
 <p>
     <p>ID Funcionario: <input type="text" name="idFuncionario"><p>
     <p>Email         : <input type="text" name="emailFuncionario"><p>
     <p>Primeiro Nome : <input type="text" name="first_nameFuncionario"><p>
     <p>Ultimo Nome   : <input type="text" name="last_nameFuncionario"><p>
     <p>Apelido       : <input type="text" name="avatarFuncionario"><p>
     <p><input type="submit" value="Confirmar" name="confirmarFun">
     <input type="reset" value="Cancelar" name="cancelarFun">
     <input type="button" value="Voltar" onClick="history.go(-1)">  
    
    </form>
</div>
    