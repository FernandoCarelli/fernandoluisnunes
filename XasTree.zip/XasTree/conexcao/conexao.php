<?php

$local = "localhost";
$user = "root";
$password  = "";
$database = "cadfuncionarios";
$conectar = new mysqli($local, $user, "", $database);

if ($conectar->connect_errno){
    echo "Houve um erro na tentativa de conexão com MSQL:(" . $conectar->connect_errno . ")" . $conectar->connect_error;
}

 $conectar->host_info . "\n";
 $conectar->close();


 ?>